# Лицензии и атрибуция

## Собственные материалы пакета
Авторские инженерные главы, маршруты, инструкции и рубрики этого пакета предоставляются на условиях **Creative Commons Attribution 4.0 International**. При распространении укажите: «TK Luau + Roblox knowledge pack, version 1.0.0, 2026-09-26» и отметьте изменения. Текст условий: https://creativecommons.org/licenses/by/4.0/legalcode .

Оригинальные Python/Luau примеры и скрипты пакета — MIT; полный текст в `LICENSE-ORIGINAL-CODE.txt`. Они предоставлены без гарантии и требуют тестирования в целевой среде.

## Первичные материалы
Roblox Creator Documentation: https://github.com/Roblox/creator-docs . По README репозитория prose — CC BY 4.0, code samples — MIT (`LICENSE` и `LICENSE-CODE`). Авторы — Roblox Corporation и contributors исходного репозитория. Настоящий ZIP не содержит полного зеркала prose; ссылки/авторский синтез не подменяют оригинал. Downloader сохраняет исходные файлы лицензий вместе с корпусом и записывает commit каждого снимка.

Luau website: https://github.com/luau-lang/site . Условия исходного LICENSE сохраняются downloader до загрузки страниц. Не переносите условия одной библиотеки на чужие RFC, форум, assets или compiler binaries. В этой поставке не распространяются сторонние изображения, модели, музыка, шрифты или бинарные инструменты.

Наличие URL не означает разрешение на использование ассета. Roblox trademarks принадлежат их владельцам. Пакет независим, не одобрен и не выпущен Roblox Corporation.
