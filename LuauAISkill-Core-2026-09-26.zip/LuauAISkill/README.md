# LuauAISkill · TK Luau + Roblox

**Source-grounded engineering skill for AI coding agents.** Russian handbook, English agent contract and Luau examples. Source review: **26 September 2026**.

> **This is the authored core, not a completed offline mirror of all official documentation.** The supplied downloader can hydrate the pinned official Roblox/Luau text in a networked environment. Download success must be verified; links and planned work are not counted as locally saved documents. Model-quality gains and Roblox Studio runtime tests have not been measured in this build.

## Start
Read [README_RU.md](README_RU.md), then give your agent [SKILL.md](SKILL.md). Choose a route from [tracks/INDEX.md](tracks/INDEX.md). Preserve the folder structure. Do not inject the whole corpus into a prompt.

[Русская инструкция](README_RU.md) · [Публикация в GitHub](PUBLISHING_RU.md) · [Методичка](handbook/INDEX.md) · [Практические рецепты](recipes/INDEX.md) · [Установка примеров](examples/INSTALL.md) · [Оценка эффекта](evals/README.md)

## Included
48 authored handbook chapters, 24 task recipes, 10 reading routes, 10 agent prompts, 26 Luau files, 96 evaluation tasks, local FTS5 search, migration reference, original-source registry, selected API metadata, integrity checks and a corpus downloader. Exact shipped inventory and executed checks are in `PACK-MANIFEST.json` and `qa/BUILD-REPORT.json`.

```sh
python tools/search.py "освещение PBR" --limit 5
python tools/api_lookup.py Lighting.LightingStyle
python -m unittest discover -s tests -v
python tools/verify_pack.py
```

## Official corpus
```sh
python tools/fetch_corpus.py
python tools/release_pack.py --require-corpus --out ../LuauAISkill-Full.zip
```
The downloader requests English textual Roblox Creator Docs, including Engine API YAML, and the Luau documentation site's source Markdown. It does not copy media, models, translated duplicate corpora or compiler binaries. The default commits are recorded in `sources/pins.json`; `--latest` must be an explicit choice.

Alternatively, after publishing this repository, run **Actions → Build full official corpus → Run workflow**. It requests the pinned documents, runs tool tests, creates the retrieval index, verifies file integrity and produces a ZIP artifact. This workflow has **not** been run by the pack builder. Its presence does not mean the corpus is already downloaded.

## Working boundaries
Type annotations are not runtime input validation. Source existence is not feature rollout. A CLI syntax check is not a Roblox runtime test. A screenshot is not a performance profile. An instruction pack changes supplied context, not model weights. Preserve server authority, data safety, device budgets and explicit test evidence.

Independent project, not endorsed by Roblox. [Licenses and attribution](licenses/NOTICE.md).
